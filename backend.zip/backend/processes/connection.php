<?php
    $server = "localhost";
    $root = "root";
    $password = "";
    $db = "db_aa-merge";

    $conn = mysqli_connect($server, $root, $password, $db) or die("Error: Unable to Connect to Database.");
?>